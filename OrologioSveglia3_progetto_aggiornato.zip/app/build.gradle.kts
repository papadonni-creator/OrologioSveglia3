plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "it.example.orologiosveglia3"
    compileSdk = 35
    defaultConfig { applicationId = "it.example.orologiosveglia3"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
