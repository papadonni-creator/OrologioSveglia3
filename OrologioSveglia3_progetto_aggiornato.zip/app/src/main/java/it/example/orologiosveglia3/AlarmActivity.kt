package it.example.orologiosveglia3

import android.app.Activity
import android.app.NotificationManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class AlarmActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var sound: MediaPlayer? = null
    private var alarmIndex = 0
    private var soundStopped = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmIndex = intent.getIntExtra("alarm", 0)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        startAlarmSound()

        val prefs = getSharedPreferences("alarms", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 20, 18, 20)
            setBackgroundColor(0xFF101820.toInt())
        }
        val note = prefs.getString("note$alarmIndex", "").orEmpty().trim()
        if (note.isNotEmpty()) {
            root.addView(TextView(this).apply {
                text = note
                textSize = 25f
                setTextColor(0xFFCC0000.toInt())
                setTypeface(null, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setBackgroundColor(0xFFFFFFFF.toInt())
                setPadding(14, 18, 14, 18)
            }, LinearLayout.LayoutParams(-1, 0, 0.8f))
        }
        root.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.ITALY).format(java.util.Date())
            textSize = 54f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, 0, 0.7f))

        val green = alarmButton("SVEGLIATI !!", 0xFF169B45.toInt())
        green.setOnTouchListener(holdToRun(prefs.getInt("greenHold", 1).coerceIn(1, 30) * 1000L) {
            stopSound()
            cancelAlarmNotification()
            finish()
        })
        root.addView(green, LinearLayout.LayoutParams(-1, 0, 1.5f))

        val red = alarmButton("SPENGI SVEGLIA", 0xFFD92727.toInt())
        red.setOnTouchListener(object : View.OnTouchListener {
            private var triggered = false
            private val longPress = Runnable {
                triggered = true
                deleteWholeAlarm()
            }
            override fun onTouch(view: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        triggered = false
                        handler.postDelayed(longPress, prefs.getInt("redHold", 2).coerceIn(1, 30) * 1000L)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longPress)
                        if (!triggered) {
                            stopSound()
                            cancelAlarmNotification()
                            AlarmPlan.snooze(this@AlarmActivity, alarmIndex)
                            finish()
                        }
                        view.performClick()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPress); return true }
                }
                return true
            }
        })
        root.addView(red, LinearLayout.LayoutParams(-1, 0, 1.5f))
        setContentView(root)
    }

    private fun alarmButton(label: String, color: Int) = Button(this).apply {
        text = label
        textSize = 25f
        setTextColor(0xFFFFFFFF.toInt())
        setTypeface(null, android.graphics.Typeface.BOLD)
        setBackgroundColor(color)
        isAllCaps = false
    }

    private fun holdToRun(durationMs: Long, action: () -> Unit) = View.OnTouchListener { view, event ->
        val runnable = view.getTag(android.R.id.custom) as? Runnable
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val task = Runnable { action() }
                view.setTag(android.R.id.custom, task)
                handler.postDelayed(task, durationMs)
                true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                runnable?.let { handler.removeCallbacks(it) }
                view.performClick()
                true
            }
            else -> true
        }
    }

    private fun startAlarmSound() {
        val prefs = getSharedPreferences("alarms", MODE_PRIVATE)
        try {
            val voicePath = prefs.getString("voicePath", null)
            sound = MediaPlayer().apply {
                if (!voicePath.isNullOrBlank() && File(voicePath).exists()) {
                    setDataSource(voicePath)
                } else {
                    val uri = prefs.getString("ringtone", null)?.let(Uri::parse)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    setDataSource(this@AlarmActivity, uri)
                }
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {
            try {
                val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                sound = MediaPlayer.create(this, fallback)?.apply { isLooping = true; start() }
            } catch (_: Exception) { }
        }
    }

    private fun stopSound() {
        if (soundStopped) return
        soundStopped = true
        try { sound?.stop() } catch (_: Exception) { }
        sound?.release()
        sound = null
    }

    private fun cancelAlarmNotification() {
        getSystemService(NotificationManager::class.java).cancel(AlarmReceiver.NOTIFICATION_BASE + alarmIndex)
    }

    private fun deleteWholeAlarm() {
        stopSound()
        getSharedPreferences("alarms", MODE_PRIVATE).edit().putBoolean("on$alarmIndex", false).apply()
        AlarmPlan.cancel(this, alarmIndex)
        cancelAlarmNotification()
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopSound()
        super.onDestroy()
    }
}
