package it.example.orologiosveglia3

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmPlan {
    private val weekdays = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
        Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)

    private fun weeklyPendingIntent(context: Context, index: Int, weekdayIndex: Int): PendingIntent =
        PendingIntent.getBroadcast(context, index * 10 + weekdayIndex,
            Intent(context, AlarmReceiver::class.java).putExtra("alarm", index),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun schedule(context: Context, index: Int) {
        val prefs = context.getSharedPreferences("alarms", Context.MODE_PRIVATE)
        val manager = context.getSystemService(AlarmManager::class.java)
        weekdays.forEachIndexed { weekdayIndex, weekday ->
            val pending = weeklyPendingIntent(context, index, weekdayIndex)
            manager.cancel(pending)
            if (!prefs.getBoolean("on$index", false) || !prefs.getBoolean("d${index}_$weekday", false)) return@forEachIndexed
            val now = Calendar.getInstance()
            val next = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_WEEK, weekday)
                set(Calendar.HOUR_OF_DAY, prefs.getInt("h$index", now.get(Calendar.HOUR_OF_DAY)))
                set(Calendar.MINUTE, prefs.getInt("m$index", now.get(Calendar.MINUTE)))
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.WEEK_OF_YEAR, 1)
            }
            if (Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
            }
        }
    }

    fun cancel(context: Context, index: Int) {
        val manager = context.getSystemService(AlarmManager::class.java)
        for (weekdayIndex in 0..6) {
            val pending = weeklyPendingIntent(context, index, weekdayIndex)
            manager.cancel(pending)
            pending.cancel()
        }
        val snooze = snoozePendingIntent(context, index)
        manager.cancel(snooze)
        snooze.cancel()
    }

    private fun snoozePendingIntent(context: Context, index: Int): PendingIntent =
        PendingIntent.getBroadcast(context, 1000 + index,
            Intent(context, AlarmReceiver::class.java).putExtra("alarm", index).putExtra("snooze", true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun snooze(context: Context, index: Int) {
        val minutes = context.getSharedPreferences("alarms", Context.MODE_PRIVATE)
            .getInt("snooze", 5).coerceIn(1, 120)
        val pending = snoozePendingIntent(context, index)
        val manager = context.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + minutes * 60_000L
        if (Build.VERSION.SDK_INT < 31 || manager.canScheduleExactAlarms()) {
            manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        } else {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
        }
    }
}
