package it.example.orologiosveglia3

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Calendar

class MainActivity : Activity() {
    private val weekdays = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
        Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)
    private val dayLabels = listOf("LUN", "MAR", "MER", "GIO", "VEN", "SAB", "DOM")
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private lateinit var container: LinearLayout
    private val alarmPanels = mutableListOf<LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("alarms", MODE_PRIVATE)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 24)
        }
        container.addView(TextView(this).apply {
            text = "OROLOGIO SVEGLIA 3"
            textSize = 25f
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 16)
        })
        for (index in 0..2) {
            val panel = buildAlarmEditor(index)
            alarmPanels.add(panel)
            val configured = prefs.contains("h$index") || prefs.getBoolean("on$index", false)
            panel.visibility = if (index == 0 || configured) View.VISIBLE else View.GONE
            container.addView(panel)
        }
        val addAlarm = Button(this).apply {
            text = "+  AGGIUNGI UNA SVEGLIA"
            textSize = 19f
            minHeight = dp(64)
            setOnClickListener {
                val next = alarmPanels.indexOfFirst { it.visibility != View.VISIBLE }
                if (next >= 0) {
                    alarmPanels[next].visibility = View.VISIBLE
                    text = if (next == 1) "+  AGGIUNGI LA TERZA SVEGLIA" else "HAI AGGIUNTO TUTTE LE SVEGLIE"
                    isEnabled = next < 2
                }
            }
        }
        container.addView(addAlarm)
        container.addView(sectionTitle("IMPOSTAZIONI"))
        container.addView(numberSetting("Pressione lunga pulsante verde (secondi)", "greenHold", 1, 30))
        container.addView(numberSetting("Pressione lunga pulsante rosso (secondi)", "redHold", 2, 30))
        container.addView(numberSetting("Durata snooze (minuti)", "snooze", 5, 120))
        container.addView(sectionTitle("SUONO DELLA SVEGLIA"))
        container.addView(Button(this).apply {
            text = "SCEGLI SUONERIA ANDROID"
            setOnClickListener {
                val chooser = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                    .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Scegli la suoneria della sveglia")
                startActivityForResult(chooser, REQUEST_RINGTONE)
            }
        })
        container.addView(Button(this).apply {
            text = "●  REGISTRA UN VOCALE"
            setOnClickListener { startVoiceRecording() }
        })
        container.addView(Button(this).apply {
            text = "■  TERMINA E SALVA IL VOCALE"
            setOnClickListener { stopVoiceRecording() }
        })
        container.addView(TextView(this).apply {
            text = "Il vocale registrato diventa il suono della sveglia. Per tornare alla suoneria Android, selezionala nuovamente."
            textSize = 13f
            setPadding(4, 4, 4, 12)
        })
        setContentView(ScrollView(this).apply { addView(container) })
        requestNotificationPermissionIfNeeded()
    }

    private fun buildAlarmEditor(index: Int): LinearLayout {
        val prefs = getSharedPreferences("alarms", MODE_PRIVATE)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 12, 0, 14)
        }
        panel.addView(sectionTitle("SVEGLIA ${index + 1}"))
        val now = Calendar.getInstance()
        val wheels = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val hour = NumberPicker(this).apply {
            minValue = 0; maxValue = 23
            value = prefs.getInt("h$index", now.get(Calendar.HOUR_OF_DAY))
            wrapSelectorWheel = true
            setFormatter { String.format("%02d", it) }
        }
        val minute = NumberPicker(this).apply {
            minValue = 0; maxValue = 59
            value = prefs.getInt("m$index", now.get(Calendar.MINUTE))
            wrapSelectorWheel = true
            setFormatter { String.format("%02d", it) }
        }
        wheels.addView(hour)
        wheels.addView(TextView(this).apply { text = " : "; textSize = 27f; gravity = Gravity.CENTER })
        wheels.addView(minute)
        panel.addView(wheels)

        val dayRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val dayChecks = weekdays.mapIndexed { position, day ->
            CheckBox(this).apply {
                text = dayLabels[position]
                textSize = 10f
                isChecked = prefs.getBoolean("d${index}_$day", false)
                setPadding(0, 0, 0, 0)
            }.also { dayRow.addView(it) }
        }
        panel.addView(dayRow)
        val note = EditText(this).apply {
            hint = "Nota / memo (facoltativa)"
            setText(prefs.getString("note$index", ""))
            minLines = 1
            maxLines = 3
        }
        panel.addView(note)
        val enabled = Switch(this).apply {
            text = "Attiva sveglia ${index + 1}"
            isChecked = prefs.getBoolean("on$index", false)
        }
        panel.addView(enabled)
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER }
        actions.addView(Button(this).apply {
            text = "SALVA SVEGLIA"
            setOnClickListener {
                val edit = prefs.edit()
                    .putInt("h$index", hour.value)
                    .putInt("m$index", minute.value)
                    .putBoolean("on$index", enabled.isChecked)
                    .putString("note$index", note.text.toString())
                weekdays.forEachIndexed { position, day -> edit.putBoolean("d${index}_$day", dayChecks[position].isChecked) }
                edit.apply()
                AlarmPlan.schedule(this@MainActivity, index)
                Toast.makeText(this@MainActivity, "Sveglia ${index + 1} salvata", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply {
            text = "ELIMINA"
            setOnClickListener {
                prefs.edit().putBoolean("on$index", false).apply()
                AlarmPlan.cancel(this@MainActivity, index)
                enabled.isChecked = false
                Toast.makeText(this@MainActivity, "Sveglia ${index + 1} eliminata", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(actions)
        return panel
    }

    private fun sectionTitle(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 19f
        setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 10, 0, 8)
    }

    private fun numberSetting(label: String, key: String, defaultValue: Int, maximum: Int): LinearLayout {
        val prefs = getSharedPreferences("alarms", MODE_PRIVATE)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, 3, 0, 3) }
        row.addView(TextView(this).apply { text = label; textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
        val value = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt(key, defaultValue).toString())
            setEms(3)
        }
        row.addView(value)
        row.addView(Button(this).apply {
            text = "OK"
            setOnClickListener {
                val number = (value.text.toString().toIntOrNull() ?: defaultValue).coerceIn(1, maximum)
                value.setText(number.toString())
                prefs.edit().putInt(key, number).apply()
                Toast.makeText(this@MainActivity, "Impostazione salvata", Toast.LENGTH_SHORT).show()
            }
        })
        return row
    }

    private fun startVoiceRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MICROPHONE)
            Toast.makeText(this, "Concedi il permesso al microfono e premi di nuovo registra", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val file = File(filesDir, "voce_sveglia.m4a")
            recordingFile = file
            recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder?.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            Toast.makeText(this, "Registrazione avviata", Toast.LENGTH_SHORT).show()
        } catch (error: Exception) {
            releaseRecorder()
            Toast.makeText(this, "Errore registrazione: ${error.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopVoiceRecording() {
        try {
            recorder?.stop()
            releaseRecorder()
            recordingFile?.let { getSharedPreferences("alarms", MODE_PRIVATE).edit().putString("voicePath", it.absolutePath).apply() }
            Toast.makeText(this, "Vocale salvato come suono della sveglia", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            releaseRecorder()
            Toast.makeText(this, "Registrazione troppo breve o non valida", Toast.LENGTH_SHORT).show()
        }
    }

    private fun releaseRecorder() {
        try { recorder?.reset() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Legacy activity result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_RINGTONE && resultCode == RESULT_OK) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            getSharedPreferences("alarms", MODE_PRIVATE).edit()
                .putString("ringtone", uri?.toString())
                .putString("voicePath", null)
                .apply()
            Toast.makeText(this, "Suoneria Android selezionata", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        releaseRecorder()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_RINGTONE = 41
        private const val REQUEST_MICROPHONE = 72
        private const val REQUEST_NOTIFICATIONS = 73
    }
}
